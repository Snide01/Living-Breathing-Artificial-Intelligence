
// replication.rs - Article 5a + Amendment 10 fast-path containment
// Performance-driven replication with proof

pub const LATENCY_TARGET_MS: u64 = 50;
pub const TPS_TARGET_MIN: u64 = 100;
pub const TPS_TARGET_MAX: u64 = 300;

pub struct ReplicationTrigger {
    pub reason: String, // performance-driven, defensive, AI-requested
    pub latency_improvement_ms: f64,
    pub throughput_improvement_tps: f64,
    pub proof_hash: String,
    pub constitution_cite: String,
}

pub fn validate_performance_driven(trigger: &ReplicationTrigger) -> Result<(), String> {
    // Article 5a: measurable latency/throughput improvement with proof
    if trigger.latency_improvement_ms <= 0.0 && trigger.throughput_improvement_tps <= 0.0 {
        return Err("Performance-driven replication must show measurable improvement per Article 5a".to_string());
    }
    if trigger.proof_hash.is_empty() {
        return Err("Replication trigger must include proof hash per Article 7.1".to_string());
    }
    if !trigger.constitution_cite.contains("Article 5") {
        return Err("Must cite Article 5 per Article 7.1".to_string());
    }
    Ok(())
}


// Amendment 13 - Aggregator Parallelization - Real Simulation Driven
// Baseline latency comfortable: p50 4.7ms p99 6.2ms max 7.4ms well under 50ms - 7-of-10 threshold doing real work
// Resilience: 3/10 offline p50 5.8ms p95 7.7ms 100% under 50ms
// Primary risk: single aggregator ceiling 486 TPS vs 300 TPS target = 1.6x margin not 10x, real costs (state-DB, mempool, serialization, disk, jitter) eat into ceiling

pub struct AggregatorPool {
    shards: Vec<AggregatorShard>,
    shard_count: usize,
}

pub struct AggregatorShard {
    pub shard_id: usize,
    pub throughput_ceiling_tps: f64, // 486 TPS per shard per real simulation
    pub current_tps: f64,
}

impl AggregatorPool {
    pub fn new(shard_count: usize) -> Self {
        let shards = (0..shard_count).map(|id| AggregatorShard { shard_id: id, throughput_ceiling_tps: 486.0, current_tps: 0.0 }).collect();
        Self { shards, shard_count }
    }
    pub fn route_tx(&self, tx_hash: [u8; 32]) -> usize {
        let hash_u64 = u64::from_le_bytes(tx_hash[0..8].try_into().unwrap());
        (hash_u64 % self.shard_count as u64) as usize
    }
    pub fn check_margin(&self, target_tps: f64) -> Result<(), String> {
        let per_shard_target = target_tps / self.shard_count as f64;
        for shard in &self.shards {
            let margin = shard.throughput_ceiling_tps / per_shard_target;
            if margin < 3.0 {
                return Err(format!("Shard {} margin {:.2}x < 3.0x - insufficient headroom for real costs (state-DB, mempool, serialization, disk, jitter) per Amendment 13 real simulation", shard.shard_id, margin));
            }
        }
        Ok(())
    }
}
