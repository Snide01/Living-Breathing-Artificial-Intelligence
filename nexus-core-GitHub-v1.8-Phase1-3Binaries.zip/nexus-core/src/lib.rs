
pub mod shared;
pub mod core {
    pub mod governance;
    pub mod reclamation;
    pub mod reputation;
    pub mod replication;
}
pub mod ai {
    pub mod ai_core_loop;
}
