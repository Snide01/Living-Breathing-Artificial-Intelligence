
// replication.rs - Article 5a + Amendment 10 fast-path containment
// Performance-driven replication with proof

pub const LATENCY_TARGET_MS: u64 = 50;
pub const TPS_TARGET_MIN: u64 = 100;
pub const TPS_TARGET_MAX: u64 = 300;

pub struct ReplicationTrigger {
    pub reason: String, // performance-driven, defensive, AI-requested
    pub latency_improvement_ms: f64,
    pub throughput_improvement_tps: f64,
    pub proof_hash: String,
    pub constitution_cite: String,
}

pub fn validate_performance_driven(trigger: &ReplicationTrigger) -> Result<(), String> {
    // Article 5a: measurable latency/throughput improvement with proof
    if trigger.latency_improvement_ms <= 0.0 && trigger.throughput_improvement_tps <= 0.0 {
        return Err("Performance-driven replication must show measurable improvement per Article 5a".to_string());
    }
    if trigger.proof_hash.is_empty() {
        return Err("Replication trigger must include proof hash per Article 7.1".to_string());
    }
    if !trigger.constitution_cite.contains("Article 5") {
        return Err("Must cite Article 5 per Article 7.1".to_string());
    }
    Ok(())
}
