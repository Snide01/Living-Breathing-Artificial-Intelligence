
// reclamation.rs - Constitution v1.7 - Amendment 6 + 12 Part B
// 4-Stage Ephemeral State Architecture
// Gasless heartbeat + Merkle root per epoch

use sha2::{Sha256, Digest};
use serde::{Serialize, Deserialize};
use std::collections::HashMap;

pub const HEARTBEAT_RATE_LIMIT_BLOCKS: u64 = 144; // 1 per day
pub const EPOCH_BLOCKS: u64 = 2016;
pub const INACTIVITY_THRESHOLD_YEARS: u64 = 5;
pub const TIMELOCK_DAYS: u64 = 90;
pub const CLAWBACK_YEARS: u64 = 3;
pub const CLAWBACK_RETURN_PERCENT: f64 = 80.0;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct HeartbeatPayload {
    pub address: String,
    pub timestamp: u64,
    pub signature: String, // gasless cryptographic signature, no tx fee
    pub reputation_score: f64,
    pub voucher_count: u8,
}

/// Stage 2: Ephemeral Memory Map - flat overhead, overwrite latest per address
pub struct HeartbeatPool {
    ephemeral_map: HashMap<String, HeartbeatPayload>, // latest per address only
    last_seen_block: HashMap<String, u64>,
}

impl HeartbeatPool {
    pub fn new() -> Self {
        Self { ephemeral_map: HashMap::new(), last_seen_block: HashMap::new() }
    }

    /// Stage 1: Gossip-Layer Rate Limiter - 1 per 144 blocks per address
    pub fn accept_heartbeat(&mut self, payload: HeartbeatPayload, current_block: u64) -> Result<(), String> {
        // Article 6.1.1: gasless, no PoP forced, no balance move, no de-anonymization
        if let Some(last) = self.last_seen_block.get(&payload.address) {
            if current_block - last < HEARTBEAT_RATE_LIMIT_BLOCKS {
                return Err(format!("Rate limited: 1 per {} blocks, last at {}", HEARTBEAT_RATE_LIMIT_BLOCKS, last));
            }
        }
        // Stage 2: overwrite not append - flat overhead
        self.ephemeral_map.insert(payload.address.clone(), payload.clone());
        self.last_seen_block.insert(payload.address, current_block);
        Ok(())
    }

    /// Stage 3: Epoch batch - zero disk writes until epoch close
    /// Stage 4: Merkle Aggregation - write root only
    pub fn close_epoch_and_merkle_root(&mut self) -> Option<String> {
        if self.ephemeral_map.is_empty() {
            return None;
        }
        let leaves: Vec<HeartbeatPayload> = self.ephemeral_map.values().cloned().collect();
        let tree = EphemeralMerkleTree::new(leaves);
        tree.get_root()
    }

    pub fn generate_inclusion_proof(&self, address: &str) -> Option<Vec<ProofNode>> {
        // For audit per Article 7 - user can prove heartbeat inclusion without permanent indexing
        let leaves: Vec<HeartbeatPayload> = self.ephemeral_map.values().cloned().collect();
        let tree = EphemeralMerkleTree::new(leaves);
        let idx = self.ephemeral_map.keys().position(|k| k == address)?;
        Some(tree.generate_inclusion_proof(idx))
    }
}

#[derive(Clone)]
pub struct ProofNode {
    pub position: String, // left or right
    pub hash: String,
}

pub struct EphemeralMerkleTree {
    leaves: Vec<String>,
    tree: Vec<Vec<String>>,
}

impl EphemeralMerkleTree {
    pub fn new(leaves_data: Vec<HeartbeatPayload>) -> Self {
        let leaves: Vec<String> = leaves_data.iter().map(|leaf| {
            let serialized = serde_json::to_string(&serde_json::json!({
                "address": leaf.address,
                "timestamp": leaf.timestamp,
                "reputation_score": leaf.reputation_score,
                "voucher_count": leaf.voucher_count
            }).to_string()
            // Canonical serialization sorted keys per spec
            let mut hasher = Sha256::new();
            hasher.update(serialized.as_bytes());
            format!("{:x}", hasher.finalize())
        }).collect();

        let mut tree = vec![leaves.clone()];
        let mut current = leaves.clone();
        while current.len() > 1 {
            let mut next = Vec::new();
            let mut i = 0;
            while i < current.len() {
                let left = &current[i];
                let right = if i+1 < current.len() { &current[i+1] } else { &current[i] };
                let mut hasher = Sha256::new();
                hasher.update((left.clone() + right).as_bytes());
                next.push(format!("{:x}", hasher.finalize()));
                i += 2;
            }
            tree.push(next.clone());
            current = next;
        }
        Self { leaves, tree }
    }

    pub fn get_root(&self) -> Option<String> {
        self.tree.last().and_then(|l| l.first().cloned())
    }

    pub fn generate_inclusion_proof(&self, leaf_index: usize) -> Vec<ProofNode> {
        let mut proof = Vec::new();
        let mut idx = leaf_index;
        for layer in self.tree.iter().take(self.tree.len()-1) {
            let is_right = idx % 2 == 0;
            let neighbor_idx = if is_right { idx+1 } else { idx-1 };
            if neighbor_idx < layer.len() {
                proof.push(ProofNode {
                    position: if is_right { "right".to_string() } else { "left".to_string() },
                    hash: layer[neighbor_idx].clone(),
                });
            }
            idx /= 2;
        }
        proof
    }
}
