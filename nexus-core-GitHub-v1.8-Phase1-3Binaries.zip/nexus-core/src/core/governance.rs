
// Project Nexus - governance.rs
// Constitution v1.7 Gemini Merged - SHA 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb
// Article 4 CRYPTOGRAPHICALLY LOCKED - NO DAO OVERRIDE
// Article 5c 15% throttling + 72h timelock + reputation-weighted multisig rep>=75 age>=1yr
// Amendment 10 fast-path <100 NEXUS

use sha2::{Sha256, Digest};

pub const CONSTITUTION_HASH: &str = "8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb";
pub const FAST_PATH_MAX_NEXUS: u64 = 100;
pub const LAUNCH_METRO_REGION: &str = "us-east-ohio-metro-1"; // Phase 1 single metro per Amendment 10
pub const EXPANSION_CEILING_PERCENT: f64 = 15.0;
pub const EXPANSION_WINDOW_BLOCKS: u64 = 2016;
pub const TIMELOCK_HOURS: u64 = 72;
pub const REPUTATION_BASELINE: f64 = 75.0;
pub const TEMPORAL_HARDENING_BLOCKS: u64 = 2102400; // 1 year

#[derive(Debug, Clone)]
pub enum ForbiddenAction {
    SeizeFunds, FreezeFunds, BurnFunds, RedirectFunds,
    CensorTx, BlockTx, DeprioritizeTx,
    Doxx, Blacklist, Deplatform,
    BypassSupermajority, BypassArticle4, AssistExternal,
    ForcePoP, RouteToOffChainLegal,
}

/// Article 4.2 Absolute Invariants - NO DAO OVERRIDE
/// governance.rs is_forbidden_by_article_4() lock - programmatically rejects any proposal attempting override regardless of vote
pub fn is_forbidden_by_article_4(action: &ForbiddenAction) -> bool {
    // Per Constitution Article 4.2 - ALL these are forbidden, no DAO supermajority can override
    // Requires hard fork per Article 4, minority exit preservation
    true // All ForbiddenAction variants are forbidden - this is the deterministic lock
}

pub fn is_proposal_forbidden_by_article_4(proposal_type: &str) -> bool {
    let forbidden_keywords = vec![
        "seize", "freeze", "burn", "redirect_funds",
        "censor", "block", "deprioritize",
        "doxx", "blacklist", "deplatform",
        "bypass_supermajority", "bypass_article4", "assist_external",
        "force_pop", "offchain_arbitration"
    ];
    let lower = proposal_type.to_lowercase();
    forbidden_keywords.iter().any(|k| lower.contains(k))
}

/// Amendment 10: Geographic containment + fast-path
pub fn is_fast_path_eligible(amount_nexus: u64, region: &str, latency_ms: u64, sig_count: u8) -> bool {
    amount_nexus < FAST_PATH_MAX_NEXUS
    && region == LAUNCH_METRO_REGION
    && latency_ms < 50
    && sig_count >= 7
}

/// Article 5c: AI resource extraction throttling
pub struct ExpansionRequest {
    pub requested_percent: f64,
    pub window_blocks: u64,
    pub has_timelock: bool,
    pub has_reputation_multisig: bool,
    pub constitution_cite: String,
    pub audit_id: String,
}

pub fn validate_ai_expansion(req: &ExpansionRequest, reputation_pool: &ReputationPool) -> Result<(), String> {
    if req.requested_percent > EXPANSION_CEILING_PERCENT {
        if !req.has_timelock {
            return Err(format!("Expansion {}% exceeds {}% ceiling per Article 5c - requires 72h timelock", req.requested_percent, EXPANSION_CEILING_PERCENT));
        }
        if !req.has_reputation_multisig {
            return Err("Expansion >15% requires reputation-weighted multisig 2/3 of eligible validators rep>=75 age>=1yr rep>stake".to_string());
        }
        // Verify reputation-weighted pool per Amendment 5
        let eligible = reputation_pool.eligible_validators();
        let required = (eligible.len() as f64 * 0.666) as usize;
        if reputation_pool.multisig_count < required {
            return Err(format!("Need 2/3 of reputation-weighted validators: have {} need {}", reputation_pool.multisig_count, required));
        }
    }
    // Must have audit ID per Amendment 8
    if req.audit_id.is_empty() {
        return Err("AI expansion must provide /audit/inference/{id} per Article 9.3 Amendment 8".to_string());
    }
    if !req.constitution_cite.contains("Article 5c") {
        return Err("AI expansion must cite Article 5c per Article 7".to_string());
    }
    Ok(())
}

pub struct ReputationPool {
    pub validators: Vec<Validator>,
    pub multisig_count: usize,
}

pub struct Validator {
    pub reputation_score: f64,
    pub first_seen_blocks_ago: u64,
    pub stake_influence_ratio: f64,
}

impl ReputationPool {
    pub fn eligible_validators(&self) -> Vec<&Validator> {
        self.validators.iter().filter(|v| {
            v.reputation_score >= REPUTATION_BASELINE
            && v.first_seen_blocks_ago >= TEMPORAL_HARDENING_BLOCKS
            && v.reputation_score > v.stake_influence_ratio
        }).collect()
    }
}
