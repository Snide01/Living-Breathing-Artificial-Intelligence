
# Phase 1 Real Simulation Results - Not Hand-Waved
## Crypto-cost assumptions deliberately biased in favor of design (failure = real signal)

### 1. Baseline latency comfortable
- p50 = 4.7ms, p99 = 6.2ms, max observed = 7.4ms — all well under 50ms target, wide margin
- 7-of-10 threshold structure means you don't wait for slowest nodes, doing real work here

### 2. Resilience holds up
- Even with 3 of 10 committee members fully offline or 20x degraded, p50 only rises to 5.8ms and p95 to 7.7ms — still 100% under 50ms bar in this model
- Threshold design genuinely robust to partial failure, not just theory

### 3. Real structural risk is single aggregator, not network or committee
- Signing load per node has massive headroom (10-95x) at both 100 and 300 TPS — not where risk lives
- Aggregator doing one serialized aggregate-verification per transaction on single core has throughput ceiling ~486 TPS once realistic per-tx overhead added
- Target range tops out at 300 TPS — margin roughly 1.6x, not 10x
- Simulation does NOT model: state-DB writes, mempool contention, serialization, disk durability, OS scheduling jitter — every one eats into 486 TPS ceiling, not 50ms latency budget
- If Phase 1 fails, best guess fails here — aggregator throughput under load — not raw consensus latency
- Falsifiable test: measure actual TPS ceiling with state-DB writes enabled

### Mitigation - Amendment 13
- Parallel aggregator sharding N=3, hash partitioning tx_hash % N, per-shard target 100 TPS ceiling 486 TPS margin 4.86x
- Pipeline overlapping Stage1 sig collection -> Stage2 aggregation BLS verify -> Stage3 state-DB write -> Stage4 mempool serialization -> Stage5 disk durability
- Implementation: src/core/replication.rs AggregatorPool route_tx() + check_margin() >=3.0x
