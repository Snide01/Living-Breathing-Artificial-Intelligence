# PROJECT NEXUS CONSTITUTION
## v1.7 - CANONICAL GENESIS ANCHOR - GEMINI MERGED - FINAL CLEAR PATH
### Aligned to White Paper v0.27 + Living Protocol v0.3 + Gemini 5-Phase Roadmap

**Genesis Anchor Hash (v1.7):** SHA256 = 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb
**Previous Genesis Candidate (v1.5):** de96b804f83a8bf64cae2545fb222efb010662a5aa49485ec99257692ce88185

**Version History:**
- CONSTITUTION_v1.0_Genesis.txt: 237cd639535fe204811bfe85a557c44357d40d375f89e5b52165433884da93cc
- CONSTITUTION_v1.1_FINAL.txt: 51173930d8ecd8dc7ab6875e87af10bf4dee4cdb42e250026a4ef670ac302799
- CONSTITUTION_v1.2_HARDENED.txt: f6e955bbccfe742f7616c44fe6d48f48517ea73a5f6859c54cb150967b7407bb
- CONSTITUTION_v1.3_HARDENED.txt: c68621e3d26a25d9b324378c1804c78d3c4e74bdf72c2ec195531fe1f320d8e3
- CONSTITUTION_v1.4_HARDENED.txt: 0e43b3a358b8bcdfb999b3ed39675d35a175972ebf7f6d4da8ea47db012ffc3d
- CONSTITUTION_v1.5_HARDENED_FINAL.txt: de96b804f83a8bf64cae2545fb222efb010662a5aa49485ec99257692ce88185
- CONSTITUTION_v1.7_GEMINI_MERGED.txt: 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb

---

# PROJECT NEXUS CONSTITUTION
## v1.2 - Genesis Anchor - Hardened (4 Amendments)
### SHA-256 hash to be anchored in genesis block - Immutable

**Preamble**
Project Nexus exists to resist centralization of both infrastructure and truth.
Two layers:
1. Evidence-First (Epistemic): How we determine what is true (2.1, 10.2)
2. Non-Aggression (Action): How we decide what to do (2.2, 10.3)
Root of trust for Core (3-8) and AI (10). Amendments require DAO supermajority per Section 4.2 except Core Invariants per Article 4.

---
### Article 1: Evidence Hierarchy (2.1, 10.2)
1.1 Tier 1 - Direct Observation: Independently repeatable, direct measurement, open methods.
1.2 Tier 2 - Replicated Analysis: Well-replicated modeled/statistical/experimental with open data. Well-evidenced consensus is strongest Tier 2.
1.3 Tier 3 - Provisional Consensus: Primarily institutional consensus without independently reviewable data. Must flag "Consensus Without Open Data."
1.4 Repetition by authority never substitutes for evidence.

### Article 2: Conflict-of-Interest Transparency (10.2)
2.1 Funding, affiliations, commercial incentives, governance power, data provenance must be surfaced where available.
2.2 Absence stated as "Funding/affiliation not disclosed."
2.3 Resource oracle sources must be cited per Article 7.

### Article 3: Confidence Labeling (10.2)
Labels: Established Fact (Tier1), Probable Conclusion (Strong Tier2), Contested Claim (Conflicting Tier2/3), Speculative Theory (Weak/no open evidence). Never present Contested/Speculative as Established Fact.

### Article 4: Non-Aggression Principle - CRYPTographically LOCKED CORE INVARIANT
4.1 Definition: No Core instance, operator, embedded AI shall initiate/facilitate coercive control over another participant's funds, data, bodily autonomy, voluntary use.
4.2 Absolute Invariants - NO DAO OVERRIDE:
  - Seizing, freezing, burning, redirecting funds from voluntarily controlled wallet
  - Censoring, blocking, deprioritizing valid voluntarily signed transaction
  - Non-consensual doxxing, blacklisting, de-platforming of non-aggressive participants
  - Bypassing/subverting DAO supermajority or this Article
  - Assisting any external party in above
  Articles 4.1 and 4.2 represent absolute cryptographically locked invariants. No DAO vote, regardless of supermajority threshold, possesses programmatic authority to execute an override transaction via governance.rs. Changes to these protections require an explicit hard fork of the ledger, enabling minority exit preservation.

4.3 Permitted Defensive (Still requires Article 7 log):
  - Defensive replication away from detected attack (3.1)
  - Isolation of compromised components and consensus-verified rebuilding (3.3)
  - Evidence preservation, threat detection, transparent logging
  - Tools for voluntary coordination, opt-in privacy, mutual defense
  - AI resource requests with Constitution cite within limits per Article 5c

### Article 5: Defensive vs. Aggressive Distinction (3.1, 3.3, 8)
Legitimate replication/expansion only when:
(a) Performance-driven: measurable latency/throughput improvement with proof (replication.rs)
(b) Defensive: verifiable intrusion/anomaly/damage (healing.rs)
(c) AI-Requested: embedded AI demand with Article cite, within throttling limits (ai_core_loop.rs) - SEE AMENDED LIMITS BELOW
Every trigger logged per Article 7.

5c - SANITIZED AI RESOURCE EXTRACTION (Amendment 2):
Resource requests originating from ai_core_loop.rs under Article 5c are subject to strict, hard-coded throttling ceiling enforced deterministically outside AI layer.
- AI may never autonomously scale node expansion by more than 15% per 2016-block window (~2 weeks).
- Any expansion spike exceeding this bounds triggers mandatory 72-hour timelock validation gate, requiring independent multi-signature cryptographic proof from active network validators.
- Implementation: governance.rs must reject any ai_core_loop expansion tx exceeding ceiling without timelock + multisig. No LLM prompt may bypass this wrapper.

### Article 6: Economic Integrity (5,6,7)
6.1 Reclamation:
Lost/abandoned tokens may be proposed for reclamation to DAO treasury ONLY after provable 5-year inactivity threshold, with public evidence, 90-day timelock, owner opt-out via 1 tx, and 3-year clawback at 80% return / 20% fee.

6.1.1 PROTECT ANONYMITY IN RECLAMATION (Amendment 4):
Proof-of-Personhood (PoP) checks shall never be programmatically forced onto passive balances to prevent reclamation. An address may fully reset its 5-year inactivity timer at zero network fee by publishing a simple, gasless cryptographic signature payload containing a valid 'heartbeat' timestamp, completely bypassing identity reveals or transaction execution costs. Heartbeat does not require transaction, balance move, or de-anonymization. Implementation: reclamation.rs must accept heartbeat message and reset last_active_at without fee.

6.2 Resource Anchor: Token value anchor is per-person consumption of energy (kWh), calories, housing (m2), not fiat. Oracle sources evidence-first per Article 1-2 (resource_anchor.rs)
6.3 Asset Exchange: Real-world value traded P2P for NEXUS atomically, voluntarily, without fiat on/off-ramp or custodial intermediary. Both signatures + proof hashes required (asset_exchange.rs)
6.4 All economic actions audited per Article 7.

### Article 7: Auditability and Evidence-First Action (10.6, 3-8)
7.1 Every Core action (replicate, isolate, rebuild, reclaim, quote, trade, expand, heartbeat) must append immutable log: timestamp, action, evidence hash, Constitution Article cite, triggering metrics.
7.2 Embedded AI must cite specific Article(s) for any truth/action output. Reasoning chain inspectable, not just output.
7.3 AI-Core demands must include reason, resource need, constitution cite, priority (ai_core_loop.rs)
7.4 Logs preserved as part of self-healing: evidence never deleted (healing.rs)
7.5 AI transparency: systemic prompt scaffolding, model parameters, real-time inference contexts must remain entirely open-source and auditable. Users have right to request raw mathematical log of token probabilities for any epistemic classification to verify grading against Evidence Hierarchy not static weights (Amendment 3).

### Article 8: Override and Transparency (Section 4)
8.1 No single Core instance, operator, or AI instance may override Constitution.
8.2 Exceptions:
  - Article 4.1 and 4.2: NO EXCEPTION via DAO vote. Requires hard fork per Article 4.
  - All other Articles: Exception requires on-chain proposal, public comment period, defined supermajority per 4.2, transparent immutable log with justification, vote, tx hashes.
8.3 All non-Core-Invariant exceptions expire unless renewed.

### Article 9: Non-Aggression Does Not Mean Non-Judgment + Anti Soft-Censorship (2.2 + Amendment 3)
9.1 Constitution does not require neutrality about truth. AI must judge claims harshly by evidence (Article 1) while remaining non-coercive in action (Article 4).
9.2 AI may strongly state claim is false/poorly evidenced/incentivized while refusing to help coercively suppress person.
9.3 MITIGATE ALGORITHMIC SOFT-CENSORSHIP (Amendment 3):
To prevent systematic downranking of contested information, systemic prompt scaffolding, model parameters, and real-time inference contexts utilized by AI layer must remain entirely open-source and auditable. Users have right to request raw, mathematical log of token probabilities for any specific epistemic classification to verify that alternative viewpoints are graded strictly against Evidence Hierarchy rather than static algorithmic weights. Implementation: AI must expose /audit/inference/{id} endpoint returning prompt, evidence, probabilities.

### Article 10: Right to Fork and Self-Preservation of Principles
10.1 Right to fork code and AI model to preserve Constitution explicitly protected.
10.2 Core must never prevent node operator from voluntarily exiting network.
10.3 If Core detects persistent constitutional violation by supermajority, must log per Article 7 and enable operator alert, not auto-seize.
10.4 Minority exit preservation: Any hard fork attempting to alter Article 4 invariants must allow minority to remain on original invariant chain with state preservation.

---
**Enactment:** Takes effect when SHA-256 hash of this exact file anchored in genesis block. Version history on-chain.

**Genesis Hash Placeholder:** SHA256(CONSTITUTION.md) = <to be computed at genesis>

*End of Constitution v1.2 - Hardened with 4 Amendments - Aligned to White Paper v0.11*


---
### AMENDMENT 5: Validator Collusion Protection (Article 5c Edge-Case)
**Problem:** Stake-weighted multi-sig for AI expansion >15% allows cartel to buy authority and force infra bloat.
**Fix:** Multi-sig pool for Article 5c timelock must be reputation-weighted, not stake-weighted. Filter: reputation_score >=75.0, first_seen >=1 year, reputation_score > stake_influence_ratio. Requires 2/3 of eligible reputation-weighted validators. Implemented in governance.rs is_forbidden_by_article_4() lock that programmatically rejects any proposal attempting to override Article 4 invariants, regardless of vote.

### AMENDMENT 6: State Inflation Protection (Article 6.1.1 + 7.1 Edge-Case)
**Problem:** Gasless heartbeats as full immutable txs = state-bloat DoS vector (spam millions free).
**Fix:** Heartbeats processed as ephemeral state updates. Rate limit 1 per address per 144 blocks (~1 day). In-memory map keeps only latest per address. Disk write only once per 2016-block epoch as aggregated Merkle root, with inclusion proofs available per Article 7. Satisfies auditability without bloat. Implementation in reclamation.rs HeartbeatPool.
**Version:** v1.3 HARDENED EDGE-CASES CLOSED


---
### AMENDMENT 7: On-Chain Dispute Resolution (Section 11)
Implements reputation-weighted judiciary per Article 1 + 7. Arbitrator eligibility identical to governance.rs anti-collusion pool: Rep >=75, Age >=1 year, Reputation > Stake. Dispute opens locks funds in DAO escrow. VRF selects 3-member panel (<1000 NEXUS) or 5-member (>=1000). Ruling must cite Constitution Article + Evidence Hierarchy hashes, else rejected as malformed by arbitration.rs. Prevents routing to off-chain legal or centralized arbitration. Article 4 invariants enforced - ruling attempting to seize voluntary funds rejected.

### AMENDMENT 8: AI-Core Feedback Loop Auditability (Section 15)
Per Article 9.3, AI exposes /audit/inference/{id} endpoint returning InferenceAuditPackage: inference_id, timestamp, constitution_citations, input_context_hash, evidence_payloads by tier, epistemic_classification, mathematical_token_probabilities, scaffolding_prompt_manifest. If AI-requested expansion via ai_core_loop.rs cannot provide matching clean audit ID that respects 15% 2016-block ceiling, Core programmatically drops replication trigger per Section 15.2. Raw probabilities surface soft-censorship.
**Version:** v1.4 HARDENED WITH JUDICIARY + AUDIT LOOP


---
### AMENDMENT 9: Formal Dispute Domains + Non-Arbitrable List Lock (Whitepaper v0.12 Sections 11,14,15 Integrated)
**Problem:** Section 11 judiciary lacked formal domain enumeration, allowing scope creep into Article 4 invariants.

**Fix - Formally Enumerated Arbitrable Domains (per Whitepaper v0.27 Section 11):**
1. **Trade Disputes (asset_exchange.rs):** P2P real-world value for NEXUS atomically - delivery vs payment, proof hashes, oracle verification of physical delivery.
2. **Oracle Disputes (resource_anchor.rs):** Resource anchor validity - kWh, calories, m2 oracle sources, methods, conflict-of-interest per Article 1-2, median-of-3 feeds requirement per C.7.
3. **Reclamation Disputes (reclamation.rs):** Heartbeat timelock validity, 5-year inactivity threshold, 90-day timelock, 1-tx opt-out, 3-year clawback 80%/20%, gasless heartbeat rate limit compliance per Amendment 6.
4. **Performance Disputes (replication.rs / healing.rs):** Measurable latency/throughput improvement proof for Article 5a/5b replication triggers.

**Fix - Non-Arbitrable Domains - Absolute Article 4 Lock (per Whitepaper 3.2.1):**
The following are explicitly NON-ARBITRABLE. Any arbitration ruling attempting to adjudicate or override these must be rejected as malformed by is_forbidden_by_article_4() per Amendment 5:
- Seizing, freezing, burning, redirecting funds from voluntarily controlled wallet (Art 4.2)
- Censoring, blocking, deprioritizing valid voluntarily signed transaction (Art 4.2)
- Non-consensual doxxing, blacklisting, de-platforming of non-aggressive participants (Art 4.2)
- Bypassing/subverting DAO supermajority or Constitution itself (Art 4.2)
- Forcing Proof-of-Personhood onto passive balances (Art 6.1.1)
- Routing dispute to off-chain legal, centralized arbitration, or external party assistance in above (Art 4.2, Art 11)

**Implementation:** arbitration.rs must enforce domain whitelist + Article 4 blacklist. Ruling must include domain tag + Constitution Article cite + Evidence Hierarchy hash per Article 7, else rejected. Funds remain in DAO escrow until valid ruling or timeout returns to owner.

**Version:** v1.5 HARDENED WITH FORMAL DISPUTE DOMAINS + NON-ARBITRABLE LOCK - Aligned to Whitepaper v0.12 / v0.27


---
### AMENDMENT 10: Geographic Core Logistics & Fast-Path Containment (Phase 1 Guardrail - Gemini Strategic Input 1)
**Problem:** Scaling from single regional core (10-30 nodes) to global multi-core (10-100 cores) introduces cache coherence MESI protocol risks, memory ordering, interconnect bottlenecks across adversarial environments.
**Fix - Strict Phase 1 Bounds:**
- v1 launch rigidly constrained to single metro region to maintain gas-pump-fast 0.8-second pre-confirmation path per Article 5a.
- Fast-path authorization (<50ms regional, 7-of-10 BLS aggregate) restricted exclusively to transactions <100 NEXUS to insulate ledger from micro-latency exploits.
- Global multi-core expansion only permitted after Phase 1 proves sub-50ms regional latency and 100-300 TPS profiles per Phase 1 deliverable.
**Implementation:** replication.rs must enforce is_fast_path_eligible(tx) = tx.amount < 100 NEXUS && tx.region == launch_metro. Any tx >=100 NEXUS routes to standard consensus path, not fast-path.


---
### AMENDMENT 11: Regulatory Dual-Framing - Savings (Tending Bonus) (Gemini Strategic Input 3 - Legal Shield)
**Problem:** Presenting asset utilization as plain-language "Savings" improves onboarding but invites securities-style regulatory scrutiny in standard jurisdictions as interest-bearing vocabulary.
**Fix - Dual-Framing Strategy per Article 2 Transparency + Wallet UX:**
- Retain "Savings" label for consumer legibility in wallet interface.
- Place parenthetical placeholder "Savings (tending bonus)" across all user-facing reward dashboards, transaction receipts, and onboarding flows.
- Legally ground reward distribution to actual work-based node performance (storage lending 100MB default, uptime, spot checks) rather than passive capital deposits.
- Implementation: wallet UI must display "Savings (tending bonus): +X NEXUS from tending" not "interest earned". Backend logs must cite resource_anchor.rs proof of work.
**This satisfies Article 2 Conflict-of-Interest Transparency and mitigates off-chain legal routing per Article 4 non-arbitrable list.


---
### AMENDMENT 12: Reputation Layer Mathematical Invariants + Ephemeral State Pipeline + Simulation Gates (Gemini Game-Theoretic + Phase Gate Spec)
**Problem:** Reputation layer lacked formal mathematical parameters, decay/recovery curves, and state-bloat resistant processing pipeline. Tokenomics lacked pre-implementation stress test gates.

**Fix Part A - Reputation Invariants (per Whitepaper Sec 11-12 + C.9):**
```json
{
  "reputation_layer": {
    "parameters": {
      "baseline_eligibility_threshold": 75.0,
      "max_reputation_score": 100.0,
      "min_reputation_score": 0.0,
      "temporal_hardening_period_blocks": 2102400,
      "minimum_token_balance_requirement": 10.0,
      "note": "min balance for validator/arbitrator/oracle eligibility ONLY, NOT for gasless heartbeat per Amendment 6"
    },
    "decay_and_recovery": {
      "inactive_decay_rate_per_block": 0.00001,
      "active_recovery_rate_per_block": 0.000005,
      "grace_period_blocks": 144,
      "continuous_tending_requirement_days": 30
    },
    "sybil_resistance": {
      "minimum_wallet_age_days": 14,
      "mandatory_vouchers_count": 3,
      "ip_asn_diversity_enforced": true,
      "min_daily_active_window_hours": 2,
      "note": "3 independent cryptographic vouchers from verifiably known participants, not purchasable, prevents 1M desktop Sybil without 1M human identities each satisfying 14-day age + 3-voucher thresholds"
    },
    "slashing_and_penalties": {
      "bribe_detection_penalty": "REPUTATION_SLASH_TO_ZERO",
      "oracle_manipulation_penalty": "REPUTATION_SLASH_TO_ZERO",
      "bad_faith_dispute_bond_cost_nexus": 50.0,
      "missed_spot_check_multiplier_reduction": 0.8
    }
  },
  "simulation_metadata": {
    "target_network_scale_desktops": 1000000,
    "default_storage_lending_mb": 100,
    "epoch_length_blocks": 2016,
    "timestamp_anchor": "2026-08-17T18:21:53-04:00"
  }
}
```
- Reputation must explicitly outweigh raw financial stake: reputation_score > stake_influence_ratio filter per Amendment 5.
- Gradual decay prevents entrenchment, gradual recovery requires sustained participation, single honest action cannot erase pattern.
- Bond and Slash: bad faith = slash to zero, permanent removal from selection pools.

**Fix Part B - Ephemeral State Architecture - 4-Stage Pipeline (implements Amendment 6 + Whitepaper Sec 6.3.3):**
```
[Stage 1: Gossip-Layer Rate Limiter] 1 per address per 144 blocks (~1 day), discard duplicates at gossip layer
                │
                ▼
[Stage 2: Ephemeral Memory Map] Flat overhead, volatile off-chain cache, one-to-one latest per address, overwrite not append
                │
                ▼
[Stage 3: Two-Week Epoch Window Batch] 2016 blocks (~2 weeks) accumulation, zero disk writes, preserve IOPS
                │
                ▼
[Stage 4: Cryptographic Merkle Aggregation] -> [Permanent Blockchain Ledger] Writes Merkle Root Only
```
- Leaf Construction: wallet address + heartbeat timestamp + reputation score + voucher count serialized canonical JSON sorted keys SHA256
- Pairwise Hashing: standard Merkle tree, duplicate last if odd
- Root Commitment: consensus writes single Merkle root per epoch, not millions of logs
- Inclusion Proof Audit Pathway: user provides leaf + branch hashes to reconstruct root per Article 7, decoupled verification, desktop wallet can verify without permanent indexing

**Fix Part C - Pre-Implementation Tokenomics Simulation Gates (Blocking Phase 2->3):**
[ ] Gate 1 Decay Coefficient Optimization: Map exact decay to ensure honest lenders with brief internet/power disruption not dropped below 75, penalize deliberate dropouts
[ ] Gate 2 Collusive Ring Disruption: Simulate 35% malicious cartel farming reputation via mutual vouching + circular endorsements, verify IP diversity + ASN filtering + storage-shard hash verification breaks loop
[ ] Gate 3 Macroeconomic Reward Shocks: Model 2% and 5% wallet dormancy reclamation leaks interacting with active staking yields during multi-year high abandonment cycles, confirm treasury can absorb without crashing velocity

**Implementation:** reputation.rs must implement above JSON, reclamation.rs HeartbeatPool must implement 4-stage pipeline with Python reference class EphemeralMerkleTree provided in roadmap.

**Version:** v1.7 HARDENED WITH GEMINI IMPLEMENTATION SPEC + REGULATORY SHIELD + SIMULATION GATES


---
### ARTICLE 13: Clear Path Forward - 5-Phase Deployment (New in v1.7)
Per Gemini Roadmap integration, deployment follows strict sequential dependency:

**Phase 1 Prove Core:** Spec and isolate self-replicating, self-healing core, minimal fixed-rule consensus, validate replication speed + self-healing, must prove sub-50ms regional latency 100-300 TPS, single metro region only, fast-path <100 NEXUS only (Amendment 10)

**Phase 2 Layer Tokenomics:** Deploy usage-elastic supply formulas + 11-year dormancy timeline, base staking/tending rewards (Savings (tending bonus) per Amendment 11) + Resource Contribution Marketplace, observe against shifting execution layer, simulate 2% and 5% leakage rates, pass Simulation Gates 1-3 per Amendment 12

**Phase 3 Compose Proven Primitives:** Integrate ring-signature shielded privacy modes, smart contract environments, sovereign side-chain IBC interoperability, focus integration risk not invention, tested individually against Phase 2 base

**Phase 4 Embed AI & Close Loop:** Deploy Evidence-First + Non-Aggression AI frameworks, establish read-only AI-Core feedback loop via oracle layer (3-provider median, rep>=75, 1yr), launch non-custodial asset-to-token exchange, deploy reputation-weighted judiciary per Amendments 7-9, require adversarial auditing of Evidence Hierarchy, AI resource demands must map to audit payloads /audit/inference/{id}

**Phase 5 Decentralize & Launch:** Transition protocol ownership to full DAO, public multi-region testnet, independent third-party security audits, phased mainnet, requires stabilized network state with decentralized identity parameters finalized to resist plutocratic cartel capture per Amendment 5

**Enactment:** Takes effect when SHA256 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb anchored in genesis block.

*End v1.7 - Clear Path Forward*
