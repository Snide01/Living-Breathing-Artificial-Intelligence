# PROJECT NEXUS WHITEPAPER
## v0.28 - Gemini Merged - Clear Path Forward
### Patch from v0.27 Living Tissue -> v0.28
### Constitution Anchor: v1.7 Gemini Merged SHA 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb
### Canonical SHA 3e48b9fd771540d0b6d65972c12335eff3b3f7b43c5da463a2b2f4bd2393b9c1

This file contains ONLY the 6 patches needed to upgrade Whitepaper v0.27 to v0.28.
Insert these into v0.27 at indicated sections. All other sections remain unchanged.

---

### PATCH 1: Section 3.2 + Section 8 Fast-Path - Add Amendment 10 Geographic Containment

INSERT AFTER existing Section 8 Performance paragraph about gas-pump-fast 0.8s:

#### Section 8.1 Geographic Core Logistics & Fast-Path Containment (New - Amendment 10)

Scaling from single regional core (10-30 nodes) to global multi-core (10-100 cores) introduces long pole of cache coherence MESI protocol.
To preserve Article 5a:
- v1 launch rigidly constrained to single metro region to maintain gas-pump-fast 0.8s pre-confirmation, must prove sub-50ms regional latency and 100-300 TPS before multi-core
- Fast-path (<50ms, 7-of-10 BLS) restricted exclusively to transactions <100 NEXUS per Amendment 10
- Transactions >=100 NEXUS route to standard consensus path

Implementation replication.rs is_fast_path_eligible(tx): amount <100 NEXUS and region==launch_metro and latency<50 and signatures>=7
Implementation governance.rs is_forbidden_by_article_4(proposal): rejects SeizeFunds Freeze Burn Redirect Censor Block Deprioritize Doxx Blacklist Deplatform BypassSupermajority BypassArticle4 AssistExternal

---

### PATCH 2: Section 5-6 + Wallet UI - Add Amendment 11 Regulatory Dual-Framing

REPLACE all wallet label Savings:
Old v0.27: Savings: +X NEXUS / staking / tending rewards
New v0.28: Savings (tending bonus): +X NEXUS from tending - 100MB storage, 30 days continuous, spot-check verified, resource_anchor.rs proof

Rationale: Plain Savings improves onboarding but invites securities scrutiny (Howey test). Dual-framing retains legibility while legally grounding reward to work-based performance not passive deposits.

Wallet JSX: label Savings (tending bonus) + reward + proof 100MB 30d spot-check verified + resource_anchor_hash
Backend log per Article 7 must cite resource_anchor.rs proof of work.

---

### PATCH 3: Section 11-12 + Appendix C.9 - Add Amendment 12 Part A Reputation Math

INSERT after rep >=75 age >=1yr reputation>stake:

Section 11.1a Reputation Layer Mathematical Invariants (New):
Parameters: baseline 75.0 max 100 min 0 temporal_hardening 2102400 blocks (1yr) min_balance 10 NEXUS for validator/arbitrator/oracle ONLY NOT for gasless heartbeat
Decay: inactive_decay 0.00001 per block active_recovery 0.000005 grace 144 blocks continuous_tending 30 days
Sybil: wallet_age 14 days vouchers 3 independent cryptographic vouchers not purchasable IP ASN diversity min 2h daily active
Slashing: bribe_detection slash to zero oracle_manipulation slash to zero bad_faith_bond 50 NEXUS missed_spot_check 0.8 multiplier

Decoupled Influence: rep > stake_influence_ratio per Amendment 5
Temporal Hardening: 1 year lifespan before fully activated, prevents burner-wallet panel stuffing
3 vouchers + IP ASN diversity: to Sybil 1M desktops need 1M human identities each 14-day + 3-voucher thresholds
Gradual decay prevents entrenchment, gradual recovery requires sustained participation
Bond and Slash: bad faith slash to zero permanent removal

---

### PATCH 4: Section 6.3.3 Ephemeral Memory + Appendix B - Add Amendment 12 Part B 4-Stage Pipeline

REPLACE Section 6.3.3 with:
Stage1 Gossip-Layer Rate Limiter 1 per address per 144 blocks discard duplicates at gossip layer
Stage2 Ephemeral Memory Map volatile off-chain cache one-to-one latest per address overwrite flat overhead denied immediate block inclusion
Stage3 Two-Week Epoch Window Batch accumulates over 2016 blocks zero disk writes preserves IOPS
Stage4 Cryptographic Merkle Aggregation writes Merkle root only Leaf Construction wallet address + heartbeat timestamp + rep score + voucher count canonical JSON sorted keys SHA256 Pairwise Hashing duplicate last if odd Root Commitment single root per epoch

Inclusion Proof Audit Pathway per Article 7: user provides leaf + branch hashes to reconstruct root, decoupled verification, desktop wallet verifies without permanent indexing

Reference implementation EphemeralMerkleTree class provided in Road_Map_to_Deployment.docx - canonical serialization sort_keys SHA256 pairwise hash

This closes Open Risk: State inflation 860GB per day -> 1 Merkle root per epoch

---

### PATCH 5: Section 16.2 Open Risks + NEW Section 13 Clear Path Forward

INSERT NEW Section 13 after Section 12:

Section 13 Clear Path Forward 5-Phase Deployment (Article 13 Gemini Roadmap):
Phase1 Prove Core: spec isolate self-replicating self-healing core minimal fixed-rule consensus validate replication + healing must prove sub-50ms 100-300 TPS single metro only fast-path <100 NEXUS Amendment 10
Phase2 Layer Tokenomics: usage-elastic supply 11yr dormancy Savings (tending bonus) per Amendment 11 Resource Contribution Marketplace 2% 5% leakage sims BLOCKING GATES per Amendment 12: Gate1 Decay Coefficient honest lenders brief outage not dropped below 75 Gate2 Collusive Ring 35% cartel mutual vouching IP diversity ASN filtering storage-shard hash Gate3 Reward Shocks treasury absorbs 2% 5% reclamation without crashing velocity - Phase2->3 BLOCKED until Gates pass
Phase3 Compose Primitives: ring-signature privacy smart contracts IBC side-chains integration risk not invention tested individually against Phase2 base
Phase4 Embed AI & Close Loop: Evidence-First Non-Aggression AI read-only oracle loop 3-provider median rep>=75 1yr rewards in kWh non-custodial asset exchange reputation-weighted judiciary VRF 3/5 adversarial audit Evidence Hierarchy AI demands map to audit payloads /audit/inference/id per Amendments 8 12
Phase5 Decentralize & Launch: DAO ownership multi-region testnet 3rd party audits phased mainnet stabilized state decentralized identity finalized resist plutocratic cartel per Amendment 5

---

### PATCH 6: Version History + Hash Update + Charts Reference

UPDATE Footer:
White Paper v0.27 Living Tissue -> v0.28 Gemini Merged Clear Path Forward
Constitution Anchor v1.7 Gemini Merged SHA 8afbbe03bc9f855465da8ccf3880d12f9c0f5e7c81ef84683e809415a4e5aedb merged canonical 3e48b9fd771540d0b6d65972c12335eff3b3f7b43c5da463a2b2f4bd2393b9c1
Roadmap document SHA 364692eb37b04d3a as implementation spec Phases 1-5
Charts /src/assets/ as evidence Section 6-7 per Article 11-12 Constitution v1.7
No changes to Article 4 invariants NO DAO OVERRIDE for seize freeze burn redirect censor block deprioritize doxx blacklist deplatform remains cryptographically locked per governance.rs is_forbidden_by_article_4()

End of Whitepaper v0.28 Patch - 6 Patches - Ready to merge into great site thread