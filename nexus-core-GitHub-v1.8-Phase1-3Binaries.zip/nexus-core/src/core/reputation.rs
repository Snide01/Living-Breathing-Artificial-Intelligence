
// reputation.rs - Amendment 12 Part A
// Formal mathematical invariants from Gemini roadmap

use serde::{Serialize, Deserialize};

pub const BASELINE_THRESHOLD: f64 = 75.0;
pub const MAX_SCORE: f64 = 100.0;
pub const MIN_SCORE: f64 = 0.0;
pub const TEMPORAL_HARDENING_BLOCKS: u64 = 2102400;
pub const MIN_BALANCE_FOR_VALIDATOR: f64 = 10.0; // NOT for heartbeat per Article 6.1.1
pub const INACTIVE_DECAY_PER_BLOCK: f64 = 0.00001;
pub const ACTIVE_RECOVERY_PER_BLOCK: f64 = 0.000005;
pub const GRACE_PERIOD_BLOCKS: u64 = 144;
pub const CONTINUOUS_TENDING_DAYS: u64 = 30;
pub const MIN_WALLET_AGE_DAYS: u64 = 14;
pub const MANDATORY_VOUCHERS: u8 = 3;
pub const MIN_DAILY_ACTIVE_HOURS: u64 = 2;
pub const BAD_FAITH_BOND_COST: f64 = 50.0;
pub const MISSED_SPOT_CHECK_MULTIPLIER: f64 = 0.8;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct ReputationState {
    pub score: f64,
    pub first_seen_block: u64,
    pub last_active_block: u64,
    pub voucher_count: u8,
    pub vouchers: Vec<String>, // independent cryptographic vouchers, not purchasable
    pub continuous_tending_days: u64,
    pub ip_asn_diversity_verified: bool,
    pub daily_active_hours: u64,
}

impl ReputationState {
    pub fn is_eligible_for_validator(&self, current_block: u64) -> bool {
        self.score >= BASELINE_THRESHOLD
        && (current_block - self.first_seen_block) >= TEMPORAL_HARDENING_BLOCKS
        && self.voucher_count >= MANDATORY_VOUCHERS
        && self.ip_asn_diversity_verified
        && self.continuous_tending_days >= CONTINUOUS_TENDING_DAYS
    }

    pub fn apply_decay(&mut self, blocks_inactive: u64) {
        if blocks_inactive <= GRACE_PERIOD_BLOCKS {
            return; // grace period
        }
        let decay = INACTIVE_DECAY_PER_BLOCK * (blocks_inactive - GRACE_PERIOD_BLOCKS) as f64;
        self.score = (self.score - decay).max(MIN_SCORE);
    }

    pub fn apply_recovery(&mut self, blocks_active: u64) {
        let recovery = ACTIVE_RECOVERY_PER_BLOCK * blocks_active as f64;
        self.score = (self.score + recovery).min(MAX_SCORE);
    }

    pub fn slash_to_zero(&mut self, reason: &str) {
        // Bond and Slash: bribe or oracle manipulation = permanent removal
        self.score = 0.0;
        // Log per Article 7
        println!("SLASH TO ZERO: {} reason: {} per Amendment 12 - permanent removal from pools", self.score, reason);
    }
}

// Sybil resistance: to Sybil 1M desktops, need 1M human identities each 14-day age + 3-voucher
pub fn verify_sybil_resistance(state: &ReputationState) -> bool {
    state.voucher_count >= MANDATORY_VOUCHERS
    && state.ip_asn_diversity_verified
    && state.daily_active_hours >= MIN_DAILY_ACTIVE_HOURS
}
