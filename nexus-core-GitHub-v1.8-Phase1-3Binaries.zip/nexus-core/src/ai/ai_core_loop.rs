
// ai_core_loop.rs - Article 5c + Article 7.3 + Amendment 8 + Amendment 10-12
// AI-Core feedback loop with auditability

use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct AICoreDemand {
    pub reason: String,
    pub resource_need: String, // kWh, storage, compute
    pub constitution_cite: String, // must cite Article 5c per Article 7.3
    pub priority: u8,
    pub evidence_hash: String,
    pub audit_id: String, // /audit/inference/{id} per Article 9.3 Amendment 8
    pub timestamp: u64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct InferenceAuditPackage {
    pub inference_id: String,
    pub timestamp: u64,
    pub constitution_citations: Vec<String>,
    pub input_context_hash: String,
    pub evidence_payloads_by_tier: EvidenceByTier,
    pub epistemic_classification: String, // Established Fact, Probable Conclusion, Contested Claim, Speculative Theory
    pub mathematical_token_probabilities: Vec<f64>, // raw probabilities to surface soft-censorship per Amendment 3
    pub scaffolding_prompt_manifest: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct EvidenceByTier {
    pub tier1_direct_observation: Vec<String>,
    pub tier2_replicated_analysis: Vec<String>,
    pub tier3_provisional_consensus: Vec<String>,
}

pub fn validate_ai_demand(demand: &AICoreDemand, audit_package: &InferenceAuditPackage) -> Result<(), String> {
    // Article 7.3: must include reason, resource need, constitution cite, priority
    if demand.constitution_cite.is_empty() {
        return Err("AI-Core demand must include constitution cite per Article 7.3".to_string());
    }
    if !demand.constitution_cite.contains("Article 5c") && demand.resource_need.contains("expansion") {
        return Err("AI expansion demand must cite Article 5c per Article 5c".to_string());
    }
    // Amendment 8: must have matching audit ID
    if demand.audit_id != audit_package.inference_id {
        return Err("AI expansion must provide matching clean audit ID per Section 15.2 Amendment 8 - Core drops trigger otherwise".to_string());
    }
    // Article 1-3: must have evidence by tier
    if audit_package.evidence_payloads_by_tier.tier1_direct_observation.is_empty() 
        && audit_package.evidence_payloads_by_tier.tier2_replicated_analysis.is_empty() {
        return Err("Audit package must include Tier1 or Tier2 evidence per Article 1 Evidence Hierarchy".to_string());
    }
    Ok(())
}
