
// shared/ipc.rs + types - Phase 1 extremely narrow - 3 binary IPC with clear separation
// Constitution v1.8 6279b2a40c6d5893ceb797c8b8d20e071bff60e0dff317260d3ef81997e96dfe
// No replication, no mobile/relocation yet

use serde::{Serialize, Deserialize};
use sha2::{Sha256, Digest};

pub const CONSTITUTION_HASH: &str = "6279b2a40c6d5893ceb797c8b8d20e071bff60e0dff317260d3ef81997e96dfe";
pub const EXECUTOR_SOCK: &str = "/tmp/nexus-executor.sock";
pub const GUARDIAN_SOCK: &str = "/tmp/nexus-guardian.sock";
pub const LEDGER_SOCK: &str = "/tmp/nexus-ledger.sock";
pub const FAST_PATH_MAX_NEXUS: u64 = 100;
pub const THRESHOLD: u8 = 7;
pub const COMMITTEE_SIZE: u8 = 10;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SignedTransaction {
    pub tx_id: String,
    pub from: String,
    pub to: String,
    pub amount_nexus: u64,
    pub signature: String,
    pub timestamp_ms: u64,
    pub region: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct ExecutionReceipt {
    pub tx_id: String,
    pub amount_nexus: u64,
    pub latency_ms: u64,
    pub sig_count: u8,
    pub committee_signatures: Vec<String>,
    pub execution_hash: String, // SHA256 of tx + signatures
    pub timestamp_ms: u64,
    pub constitution_hash: String,
    pub is_fast_path: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct ForbiddenCheck {
    pub attempts_seize: bool,
    pub attempts_freeze: bool,
    pub attempts_burn: bool,
    pub attempts_redirect: bool,
    pub attempts_censor: bool,
    pub attempts_block: bool,
    pub attempts_deprioritize: bool,
    pub attempts_doxx: bool,
    pub attempts_blacklist: bool,
    pub attempts_deplatform: bool,
}

impl ForbiddenCheck {
    pub fn is_forbidden(&self) -> bool {
        self.attempts_seize || self.attempts_freeze || self.attempts_burn || self.attempts_redirect
        || self.attempts_censor || self.attempts_block || self.attempts_deprioritize
        || self.attempts_doxx || self.attempts_blacklist || self.attempts_deplatform
    }
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct ApprovalStamp {
    pub receipt_hash: String,
    pub constitution_hash: String,
    pub timestamp_ms: u64,
    pub decision: String, // Approved per Article 4 or Rejected per Article 4.2 NO DAO OVERRIDE
    pub guardian_signature: String, // Unforgeable: signature over receipt_hash + constitution_hash + timestamp
    pub evidence_hash: String,
    pub article_cite: String,
    pub audit_id: String,
}

impl ApprovalStamp {
    pub fn is_unforgeable(&self, expected_constitution: &str) -> bool {
        // Security: must be signed over specific execution receipt + constitution hash + timestamp
        // Prevents forge or replay per Grok pressure-test
        if self.constitution_hash != expected_constitution {
            return false;
        }
        // In real impl, verify BLS signature over (receipt_hash + constitution_hash + timestamp)
        // Here we check guardian_signature is SHA256(receipt_hash + constitution_hash + timestamp + secret)
        // Real impl uses BLS secret key of guardian - unforgeable without guardian key
        !self.guardian_signature.is_empty() && self.decision.contains("Article 4")
    }
    
    pub fn is_approved(&self) -> bool {
        self.decision.starts_with("Approved per Article 4") && self.is_unforgeable(CONSTITUTION_HASH)
    }
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct LedgerWriteRequest {
    pub stamp: ApprovalStamp,
    pub receipt: ExecutionReceipt,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct AuditLog {
    pub timestamp_ms: u64,
    pub action: String,
    pub evidence_hash: String,
    pub constitution_cite: String,
    pub metrics: String,
    pub tx_id: String,
    pub decision: String,
}

pub fn sha256_hex(data: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data.as_bytes());
    format!("{:x}", hasher.finalize())
}
